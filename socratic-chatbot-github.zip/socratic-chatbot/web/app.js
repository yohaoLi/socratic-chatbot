const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const resetBtn = document.getElementById("resetBtn");
const messages = document.getElementById("messages");

let sessionId = localStorage.getItem("socratic_session_id") || null;
let pendingNode = null;

function scrollToBottom() {
  messages.scrollTop = messages.scrollHeight;
}

function addMessage(role, text, extraClass = "") {
  document.body.classList.add("has-chat");
  const article = document.createElement("article");
  article.className = `message ${role} ${extraClass}`.trim();

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  article.appendChild(bubble);
  messages.appendChild(article);
  scrollToBottom();
  return article;
}

function setBusy(isBusy) {
  sendBtn.disabled = isBusy;
  input.disabled = isBusy;
}

function autosize() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 160)}px`;
}

input.addEventListener("input", autosize);

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const text = input.value.trim();
  if (!text) return;

  addMessage("user", text);
  input.value = "";
  autosize();
  setBusy(true);
  pendingNode = addMessage("assistant", "思考中...", "pending");

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: text,
        session_id: sessionId,
      }),
    });

    if (!response.ok) {
      const detail = await response.text();
      throw new Error(detail || `HTTP ${response.status}`);
    }

    const data = await response.json();
    sessionId = data.session_id;
    localStorage.setItem("socratic_session_id", sessionId);

    pendingNode.classList.remove("pending");
    pendingNode.querySelector(".bubble").textContent = data.reply;
  } catch (error) {
    pendingNode.classList.remove("pending");
    pendingNode.querySelector(".bubble").textContent =
      `请求失败：${error.message}`;
  } finally {
    pendingNode = null;
    setBusy(false);
    input.focus();
    scrollToBottom();
  }
});

resetBtn.addEventListener("click", async () => {
  const oldSession = sessionId;
  sessionId = null;
  localStorage.removeItem("socratic_session_id");
  messages.innerHTML = "";
  document.body.classList.remove("has-chat");

  if (oldSession) {
    await fetch("/api/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: oldSession }),
    }).catch(() => {});
  }
});

autosize();
