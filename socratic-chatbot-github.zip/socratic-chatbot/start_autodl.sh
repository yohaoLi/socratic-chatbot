#!/usr/bin/env bash
set -e

BASE_MODEL="${SOCRATIC_BASE_MODEL:-/root/autodl-tmp/models/Qwen3-4B-Instruct-2507}"
ADAPTER="${SOCRATIC_ADAPTER:-/root/socratic-chatbot/outputs/socratic-qwen3-4b-lora-v6}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-6006}"

python app.py   --base-model "$BASE_MODEL"   --adapter "$ADAPTER"   --host "$HOST"   --port "$PORT"
