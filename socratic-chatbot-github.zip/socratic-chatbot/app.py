import argparse
import asyncio
import os
import uuid
from pathlib import Path

import torch
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

from inference.chat_reversal import (
    DEFAULT_PROMPT,
    generate_reply,
    load_system_prompt,
    safety_reply,
    trim_history,
)


ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    session_id: str | None = None
    max_new_tokens: int = Field(default=180, ge=32, le=512)
    temperature: float = Field(default=0.45, ge=0.0, le=1.5)
    top_p: float = Field(default=0.85, ge=0.1, le=1.0)


class ChatResponse(BaseModel):
    session_id: str
    reply: str


class ResetRequest(BaseModel):
    session_id: str | None = None


class ModelState:
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.system_prompt = ""
        self.sessions: dict[str, list[dict[str, str]]] = {}
        self.lock = asyncio.Lock()

    def new_history(self):
        return [{"role": "system", "content": self.system_prompt}]

    def get_history(self, session_id):
        if session_id not in self.sessions:
            self.sessions[session_id] = self.new_history()
        return self.sessions[session_id]


state = ModelState()
app = FastAPI(title="Socratic Reversal ChatBot")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def load_model(base_model, adapter, system_prompt_path):
    state.system_prompt = load_system_prompt(system_prompt_path)

    state.tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
    if state.tokenizer.pad_token is None:
        state.tokenizer.pad_token = state.tokenizer.eos_token

    dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    )
    if adapter:
        model = PeftModel.from_pretrained(model, adapter)

    model.eval()
    state.model = model


@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")


@app.get("/api/health")
def health():
    return {
        "ok": state.model is not None and state.tokenizer is not None,
        "sessions": len(state.sessions),
    }


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    if state.model is None or state.tokenizer is None:
        raise HTTPException(status_code=503, detail="Model is still loading.")

    user_text = req.message.strip()
    if not user_text:
        raise HTTPException(status_code=400, detail="Message is empty.")

    session_id = req.session_id or uuid.uuid4().hex
    history = state.get_history(session_id)

    fixed = safety_reply(user_text)
    if fixed:
        history.append({"role": "user", "content": user_text})
        history.append({"role": "assistant", "content": fixed})
        state.sessions[session_id] = trim_history(history)
        return ChatResponse(session_id=session_id, reply=fixed)

    history.append({"role": "user", "content": user_text})

    async with state.lock:
        reply = await asyncio.to_thread(
            generate_reply,
            state.model,
            state.tokenizer,
            trim_history(history),
            req.max_new_tokens,
            req.temperature,
            req.top_p,
        )

    history.append({"role": "assistant", "content": reply})
    state.sessions[session_id] = trim_history(history)
    return ChatResponse(session_id=session_id, reply=reply)


@app.post("/api/reset")
def reset(req: ResetRequest):
    if req.session_id:
        state.sessions.pop(req.session_id, None)
    return {"ok": True}


app.mount("/web", StaticFiles(directory=WEB_DIR), name="web")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-model",
        default=os.environ.get("SOCRATIC_BASE_MODEL", "/root/autodl-tmp/models/Qwen3-4B-Instruct-2507"),
    )
    parser.add_argument(
        "--adapter",
        default=os.environ.get("SOCRATIC_ADAPTER", "/root/socratic-chatbot/outputs/socratic-qwen3-4b-lora-v6"),
    )
    parser.add_argument(
        "--system-prompt",
        type=Path,
        default=Path(os.environ.get("SOCRATIC_SYSTEM_PROMPT", str(DEFAULT_PROMPT))),
    )
    parser.add_argument("--host", default=os.environ.get("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "7860")))
    return parser.parse_args()


def main():
    args = parse_args()
    load_model(args.base_model, args.adapter, args.system_prompt)

    import uvicorn

    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
