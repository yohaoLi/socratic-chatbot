import argparse
import json
from pathlib import Path

import torch
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)

IGNORE_INDEX = -100
SYSTEM = "你是一个苏格拉底式哲学陪伴助手，温和、清醒、适度提问，擅长帮助用户检查自己的判断。"


def load_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"bad json on line {line_no}: {exc}") from exc
    return rows


def fallback_chat_template(messages, add_generation_prompt=False):
    parts = []
    for msg in messages:
        parts.append(f"<{msg['role']}>\n{msg['content'].strip()}\n</{msg['role']}>\n")
    if add_generation_prompt:
        parts.append("<assistant>\n")
    return "".join(parts)


def apply_chat_template(tokenizer, messages, add_generation_prompt=False):
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
    return fallback_chat_template(messages, add_generation_prompt=add_generation_prompt)


def normalize_messages(messages):
    if not messages or messages[0]["role"] != "system":
        return [{"role": "system", "content": SYSTEM}] + messages
    return messages


def build_feature(tokenizer, example, max_length):
    messages = normalize_messages(example["messages"])
    assistant_indices = [
        i for i, msg in enumerate(messages) if msg["role"] == "assistant"
    ]
    if not assistant_indices:
        raise ValueError("sample has no assistant message")

    # For multi-turn SFT, use the dialogue history as the prompt and train only
    # the final assistant answer. Earlier assistant turns remain context.
    final_assistant_index = assistant_indices[-1]
    prompt_messages = messages[:final_assistant_index]

    full_text = apply_chat_template(
        tokenizer,
        messages,
        add_generation_prompt=False,
    )
    prompt_text = apply_chat_template(
        tokenizer,
        prompt_messages,
        add_generation_prompt=True,
    )

    full = tokenizer(
        full_text,
        truncation=True,
        max_length=max_length,
        add_special_tokens=False,
    )
    prompt = tokenizer(
        prompt_text,
        truncation=True,
        max_length=max_length,
        add_special_tokens=False,
    )

    input_ids = full["input_ids"]
    labels = input_ids.copy()
    prompt_len = min(len(prompt["input_ids"]), len(labels))
    labels[:prompt_len] = [IGNORE_INDEX] * prompt_len

    return {
        "input_ids": input_ids,
        "attention_mask": full["attention_mask"],
        "labels": labels,
    }


class SFTDataCollator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, features):
        max_len = max(len(x["input_ids"]) for x in features)
        batch = {"input_ids": [], "attention_mask": [], "labels": []}

        for x in features:
            pad_len = max_len - len(x["input_ids"])
            batch["input_ids"].append(
                x["input_ids"] + [self.tokenizer.pad_token_id] * pad_len
            )
            batch["attention_mask"].append(x["attention_mask"] + [0] * pad_len)
            batch["labels"].append(x["labels"] + [IGNORE_INDEX] * pad_len)

        return {k: torch.tensor(v, dtype=torch.long) for k, v in batch.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, help="Base model name or local path.")
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("/workspace/socratic-chatbot/data/train_socratic_v1.jsonl"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("/workspace/socratic-chatbot/outputs/socratic-lora"),
    )
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--epochs", type=float, default=3.0)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--grad-accum", type=int, default=8)
    parser.add_argument("--logging-steps", type=int, default=1)
    parser.add_argument("--save-steps", type=int, default=50)
    parser.add_argument("--bf16", action="store_true")
    parser.add_argument(
        "--target-modules",
        nargs="+",
        default=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        help="LoRA target modules. This default fits many LLaMA/Qwen-style models.",
    )
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    rows = load_jsonl(args.data)
    dataset = Dataset.from_list(rows)
    dataset = dataset.map(
        lambda x: build_feature(tokenizer, x, args.max_length),
        remove_columns=dataset.column_names,
    )

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        trust_remote_code=True,
        device_map="auto",
    )
    model.config.use_cache = False

    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=args.target_modules,
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    training_args = TrainingArguments(
        output_dir=str(args.output_dir),
        num_train_epochs=args.epochs,
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        logging_steps=args.logging_steps,
        save_steps=args.save_steps,
        save_total_limit=2,
        bf16=args.bf16,
        report_to=[],
        remove_unused_columns=False,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        data_collator=SFTDataCollator(tokenizer),
    )
    trainer.train()
    trainer.save_model(str(args.output_dir))
    tokenizer.save_pretrained(str(args.output_dir))


if __name__ == "__main__":
    main()
