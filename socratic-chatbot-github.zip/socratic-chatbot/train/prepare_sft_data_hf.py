import argparse
import json
from pathlib import Path

from transformers import AutoTokenizer

IGNORE_INDEX = -100


def load_jsonl(path):
    samples = []
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                samples.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"bad json on line {line_no}: {exc}") from exc
    return samples


def fallback_chat_template(messages, add_generation_prompt=False):
    parts = []
    for msg in messages:
        role = msg["role"]
        content = msg["content"].strip()
        parts.append(f"<{role}>\n{content}\n</{role}>\n")
    if add_generation_prompt:
        parts.append("<assistant>\n")
    return "".join(parts)


def apply_chat_template(tokenizer, messages, add_generation_prompt=False):
    if getattr(tokenizer, "chat_template", None):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
    return fallback_chat_template(messages, add_generation_prompt=add_generation_prompt)


def build_feature(tokenizer, sample, max_length):
    messages = sample["messages"]
    assistant_indices = [
        i for i, msg in enumerate(messages) if msg["role"] == "assistant"
    ]
    if not assistant_indices:
        raise ValueError("sample has no assistant message")

    final_assistant_index = assistant_indices[-1]

    # Full text contains prompt + assistant answer.
    full_text = apply_chat_template(
        tokenizer,
        messages,
        add_generation_prompt=False,
    )

    # Prompt text contains the full dialogue history before the final assistant
    # answer, plus the assistant header. This also supports multi-turn samples.
    prompt_messages = messages[:final_assistant_index]
    prompt_text = apply_chat_template(
        tokenizer,
        prompt_messages,
        add_generation_prompt=True,
    )

    full = tokenizer(
        full_text,
        truncation=True,
        max_length=max_length,
        add_special_tokens=False,
    )
    prompt = tokenizer(
        prompt_text,
        truncation=True,
        max_length=max_length,
        add_special_tokens=False,
    )

    input_ids = full["input_ids"]
    attention_mask = full["attention_mask"]
    labels = input_ids.copy()

    prompt_len = min(len(prompt["input_ids"]), len(labels))
    labels[:prompt_len] = [IGNORE_INDEX] * prompt_len

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels,
        "full_text": full_text,
        "prompt_text": prompt_text,
    }


def print_mask_preview(tokenizer, feature):
    supervised_ids = [
        token_id
        for token_id, label in zip(feature["input_ids"], feature["labels"])
        if label != IGNORE_INDEX
    ]
    supervised_text = tokenizer.decode(supervised_ids, skip_special_tokens=False)

    print("=== prompt text, masked from loss ===")
    print(feature["prompt_text"])
    print("=== full text ===")
    print(feature["full_text"])
    print("=== supervised assistant text ===")
    print(supervised_text)
    print("=== stats ===")
    print(f"total tokens: {len(feature['input_ids'])}")
    print(f"masked tokens: {sum(x == IGNORE_INDEX for x in feature['labels'])}")
    print(f"supervised tokens: {sum(x != IGNORE_INDEX for x in feature['labels'])}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, help="Base model name or local path.")
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("/workspace/socratic-chatbot/data/train_socratic_v1.jsonl"),
    )
    parser.add_argument("--index", type=int, default=0)
    parser.add_argument("--max-length", type=int, default=1024)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    samples = load_jsonl(args.data)
    feature = build_feature(tokenizer, samples[args.index], args.max_length)
    print(f"loaded samples: {len(samples)}")
    print_mask_preview(tokenizer, feature)


if __name__ == "__main__":
    main()
