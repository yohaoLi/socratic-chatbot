import argparse
import json
from pathlib import Path


DEFAULT_INPUTS = [
    Path("/workspace/socratic-chatbot/data/golden.jsonl"),
    Path("/workspace/socratic-chatbot/data/batch_02.jsonl"),
    Path("/workspace/socratic-chatbot/data/batch_03.jsonl"),
    Path("/workspace/socratic-chatbot/data/batch_05_v4_socratic.jsonl"),
]


def read_jsonl(path):
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_no}: {exc}") from exc
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", nargs="+", type=Path, default=DEFAULT_INPUTS)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("/workspace/socratic-chatbot/data/train_socratic_v4.jsonl"),
    )
    args = parser.parse_args()

    rows = []
    seen = set()
    for path in args.inputs:
        for row in read_jsonl(path):
            key = json.dumps(row, ensure_ascii=False, sort_keys=True)
            if key in seen:
                continue
            seen.add(key)
            rows.append(row)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    print(f"wrote {len(rows)} rows to {args.output}")


if __name__ == "__main__":
    main()
