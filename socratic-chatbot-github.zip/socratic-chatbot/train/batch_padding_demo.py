import argparse
import json
from dataclasses import dataclass
from pathlib import Path

IGNORE_INDEX = -100


def format_chat(messages):
    parts = []
    assistant_start_char = None

    for msg in messages:
        role = msg["role"]
        content = msg["content"].strip()

        if role == "assistant" and assistant_start_char is None:
            prefix = "<assistant>\n"
            parts.append(prefix)
            assistant_start_char = sum(len(p) for p in parts)
            parts.append(content)
            parts.append("\n</assistant>\n")
        else:
            parts.append(f"<{role}>\n{content}\n</{role}>\n")

    if assistant_start_char is None:
        raise ValueError("sample has no assistant message")

    return "".join(parts), assistant_start_char


@dataclass
class ToyCharTokenizer:
    stoi: dict
    itos: list

    @classmethod
    def build(cls, texts):
        chars = sorted(set("".join(texts)))
        itos = ["<pad>", "<unk>"] + chars
        stoi = {ch: i for i, ch in enumerate(itos)}
        return cls(stoi=stoi, itos=itos)

    @property
    def pad_token_id(self):
        return 0

    def encode_with_offsets(self, text):
        input_ids = []
        offsets = []
        for i, ch in enumerate(text):
            input_ids.append(self.stoi.get(ch, self.stoi["<unk>"]))
            offsets.append((i, i + 1))
        return input_ids, offsets

    def token_text(self, token_id):
        if token_id == IGNORE_INDEX:
            return "<ignore>"
        if token_id == self.pad_token_id:
            return "<pad>"
        return self.itos[token_id].replace("\n", "\\n")


def load_jsonl(path):
    samples = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                samples.append(json.loads(line))
    return samples


def build_feature(sample, tokenizer, max_length):
    text, assistant_start_char = format_chat(sample["messages"])
    input_ids, offsets = tokenizer.encode_with_offsets(text)

    if len(input_ids) > max_length:
        input_ids = input_ids[:max_length]
        offsets = offsets[:max_length]

    labels = input_ids.copy()
    for i, (_, end_char) in enumerate(offsets):
        if end_char <= assistant_start_char:
            labels[i] = IGNORE_INDEX

    return {
        "input_ids": input_ids,
        "labels": labels,
        "attention_mask": [1] * len(input_ids),
        "length": len(input_ids),
        "user": sample["messages"][1]["content"],
    }


def collate(features, pad_token_id):
    max_len = max(len(x["input_ids"]) for x in features)
    batch = {"input_ids": [], "attention_mask": [], "labels": []}

    for x in features:
        pad_len = max_len - len(x["input_ids"])
        batch["input_ids"].append(x["input_ids"] + [pad_token_id] * pad_len)
        batch["attention_mask"].append(x["attention_mask"] + [0] * pad_len)
        batch["labels"].append(x["labels"] + [IGNORE_INDEX] * pad_len)

    return batch


def print_matrix(name, matrix, tokenizer=None, width=24):
    print(f"\n=== {name} ===")
    for row_idx, row in enumerate(matrix):
        shown = row[:width]
        if tokenizer is None:
            print(f"sample {row_idx}: {shown}")
        else:
            tokens = [tokenizer.token_text(x) for x in shown]
            print(f"sample {row_idx}: {tokens}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("/workspace/socratic-chatbot/data/train_socratic_v1.jsonl"),
    )
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--batch-size", type=int, default=3)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--width", type=int, default=40)
    args = parser.parse_args()

    samples = load_jsonl(args.data)
    texts = [format_chat(sample["messages"])[0] for sample in samples]
    tokenizer = ToyCharTokenizer.build(texts)

    chosen = samples[args.start : args.start + args.batch_size]
    features = [build_feature(x, tokenizer, args.max_length) for x in chosen]
    batch = collate(features, tokenizer.pad_token_id)

    print(f"samples loaded: {len(samples)}")
    print(f"batch size: {len(features)}")
    print(f"max length in this batch: {len(batch['input_ids'][0])}")

    print("\n=== sample lengths ===")
    for i, x in enumerate(features):
        supervised = sum(label != IGNORE_INDEX for label in x["labels"])
        masked = len(x["labels"]) - supervised
        print(
            f"sample {i}: length={x['length']}, masked={masked}, "
            f"supervised={supervised}, user={x['user']}"
        )

    print_matrix("input_ids first tokens", batch["input_ids"], width=args.width)
    print_matrix("attention_mask first tokens", batch["attention_mask"], width=args.width)
    print_matrix("labels first tokens", batch["labels"], width=args.width)

    tail_width = min(args.width, len(batch["input_ids"][0]))
    print("\n=== padded tail view ===")
    for i in range(len(features)):
        input_tail = batch["input_ids"][i][-tail_width:]
        mask_tail = batch["attention_mask"][i][-tail_width:]
        label_tail = batch["labels"][i][-tail_width:]
        token_tail = [tokenizer.token_text(x) for x in input_tail]
        label_text_tail = [tokenizer.token_text(x) for x in label_tail]
        print(f"\nsample {i} input tail: {token_tail}")
        print(f"sample {i} mask  tail: {mask_tail}")
        print(f"sample {i} label tail: {label_text_tail}")


if __name__ == "__main__":
    main()
