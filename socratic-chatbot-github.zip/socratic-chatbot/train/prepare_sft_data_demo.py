import argparse
import json
from dataclasses import dataclass
from pathlib import Path

IGNORE_INDEX = -100


def format_chat(messages):
    """Use a simple chat template so the prompt and answer boundary is visible."""
    parts = []
    assistant_start_char = None

    for msg in messages:
        role = msg["role"]
        content = msg["content"].strip()

        if role == "assistant" and assistant_start_char is None:
            prefix = "<assistant>\n"
            parts.append(prefix)
            assistant_start_char = sum(len(p) for p in parts)
            parts.append(content)
            parts.append("\n</assistant>\n")
        else:
            parts.append(f"<{role}>\n{content}\n</{role}>\n")

    if assistant_start_char is None:
        raise ValueError("sample has no assistant message")

    return "".join(parts), assistant_start_char


@dataclass
class ToyCharTokenizer:
    stoi: dict
    itos: list

    @classmethod
    def build(cls, texts):
        chars = sorted(set("".join(texts)))
        itos = ["<pad>", "<unk>"] + chars
        stoi = {ch: i for i, ch in enumerate(itos)}
        return cls(stoi=stoi, itos=itos)

    @property
    def pad_token_id(self):
        return 0

    def encode_with_offsets(self, text):
        input_ids = []
        offsets = []
        for i, ch in enumerate(text):
            input_ids.append(self.stoi.get(ch, self.stoi["<unk>"]))
            offsets.append((i, i + 1))
        return input_ids, offsets

    def decode_id(self, token_id):
        if token_id == IGNORE_INDEX:
            return "<masked>"
        if 0 <= token_id < len(self.itos):
            return self.itos[token_id].replace("\n", "\\n")
        return "<bad_id>"


def build_sft_features(sample, tokenizer, max_length=512):
    text, assistant_start_char = format_chat(sample["messages"])
    input_ids, offsets = tokenizer.encode_with_offsets(text)

    if len(input_ids) > max_length:
        input_ids = input_ids[:max_length]
        offsets = offsets[:max_length]

    attention_mask = [1] * len(input_ids)
    labels = input_ids.copy()

    for i, (_, end_char) in enumerate(offsets):
        if end_char <= assistant_start_char:
            labels[i] = IGNORE_INDEX

    return {
        "text": text,
        "assistant_start_char": assistant_start_char,
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels,
    }


def load_jsonl(path):
    samples = []
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                samples.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"bad json on line {line_no}: {exc}") from exc
    return samples


def print_token_table(features, tokenizer, limit=180):
    print("\n=== token-level view ===")
    print("idx | token | input_id | label")
    print("-" * 42)
    for i, (input_id, label) in enumerate(
        zip(features["input_ids"][:limit], features["labels"][:limit])
    ):
        token = tokenizer.decode_id(input_id)
        label_text = tokenizer.decode_id(label)
        print(f"{i:>3} | {token:<7} | {input_id:>8} | {label_text}")

    if len(features["input_ids"]) > limit:
        print(f"... truncated table, total tokens: {len(features['input_ids'])}")


def print_loss_spans(features, tokenizer):
    supervised_ids = [
        token_id
        for token_id, label in zip(features["input_ids"], features["labels"])
        if label != IGNORE_INDEX
    ]
    supervised_text = "".join(tokenizer.decode_id(i).replace("\\n", "\n") for i in supervised_ids)

    print("\n=== full formatted text ===")
    print(features["text"])

    print("=== supervised assistant text ===")
    print(supervised_text)

    total = len(features["labels"])
    supervised = sum(label != IGNORE_INDEX for label in features["labels"])
    masked = total - supervised
    print("=== stats ===")
    print(f"total tokens: {total}")
    print(f"masked tokens: {masked}")
    print(f"supervised tokens: {supervised}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("/workspace/socratic-chatbot/data/train_socratic_v1.jsonl"),
    )
    parser.add_argument("--index", type=int, default=0)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--table-limit", type=int, default=180)
    args = parser.parse_args()

    samples = load_jsonl(args.data)
    formatted_texts = [format_chat(sample["messages"])[0] for sample in samples]
    tokenizer = ToyCharTokenizer.build(formatted_texts)

    sample = samples[args.index]
    features = build_sft_features(sample, tokenizer, max_length=args.max_length)

    print(f"loaded samples: {len(samples)}")
    print(f"toy vocab size: {len(tokenizer.itos)}")
    print_loss_spans(features, tokenizer)
    print_token_table(features, tokenizer, limit=args.table_limit)


if __name__ == "__main__":
    main()
