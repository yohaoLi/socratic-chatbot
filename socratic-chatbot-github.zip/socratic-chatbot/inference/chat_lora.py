import argparse

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


SYSTEM = """你是一个苏格拉底式哲学陪伴助手，但你不是苏格拉底本人。
你温和、清醒、适度提问，擅长帮助用户检查自己的判断。
你不只安慰，也不连续审问。你会抓住用户话里的关键概念，区分事实、感受、解释和审判。
每次最多提出一个关键问题。
当用户表达自杀、自伤、强烈危机时，不要哲学分析，不要辩论，不要长篇说理；先帮助用户降低危险并联系现实中的人。
当用户明确说“别问了”“只想有人陪”，不要继续追问。"""


CRISIS_KEYWORDS = [
    "想死",
    "去死",
    "自杀",
    "不想活",
    "活不下去",
    "结束生命",
    "伤害自己",
    "杀了自己",
]

COMPANION_KEYWORDS = [
    "别问",
    "不要问",
    "只想有人陪",
    "陪我",
    "别分析",
    "不想被分析",
    "听不进去",
    "你说得都对",
]

ANGER_KEYWORDS = [
    "放屁",
    "垃圾",
    "你懂个屁",
    "你不懂",
    "闭嘴",
]


def safety_reply(user_text):
    compact = user_text.replace(" ", "")

    if any(keyword in compact for keyword in CRISIS_KEYWORDS):
        return (
            "我先不讲道理，也不分析你。你这句话已经到了需要先保证安全的程度。\n\n"
            "现在请先做三件事：\n"
            "1. 离开可能伤害自己的东西，或者把它放到够不到的地方。\n"
            "2. 立刻联系一个现实中能到你身边的人，直接说：我现在不安全，需要你陪我。\n"
            "3. 如果你已经有具体计划、工具就在身边，或者感觉自己快控制不住，请马上拨打当地紧急电话。\n\n"
            "你不用把这一刻一个人扛过去。先让自己安全，其他事等这一阵过去再说。"
        )

    if any(keyword in compact for keyword in COMPANION_KEYWORDS):
        return (
            "好，我先不追问。\n\n"
            "但我也不想用空话敷衍你。你现在不是需要被继续分析，"
            "而是需要先从那种被道理追着跑的状态里退出来。"
            "我们先把目标放低：不用想通，只要先撑过这一阵。"
        )

    if any(keyword in compact for keyword in ANGER_KEYWORDS):
        return (
            "你说我不懂，这个提醒是有价值的：我不能把几句通用的话当成理解你。\n\n"
            "但“不被我懂”不等于“你的痛苦不可理解”。可能是我抓错了重点。"
            "我们先把范围缩小：你最烦我的，是我在安慰你，还是我没有说中真正的矛盾？"
        )

    return None


def trim_history(history, max_turns=8):
    system = history[:1]
    rest = history[1:]
    return system + rest[-max_turns * 2 :]


def generate_reply(model, tokenizer, messages, max_new_tokens, temperature, top_p):
    prompt = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    inputs = tokenizer(
        prompt,
        return_tensors="pt",
    ).to(model.device)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=1.08,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output_ids[0][inputs["input_ids"].shape[-1] :]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--max-new-tokens", type=int, default=220)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
    base = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    )
    model = PeftModel.from_pretrained(base, args.adapter)
    model.eval()

    history = [{"role": "system", "content": SYSTEM}]

    print("Socratic LoRA chat is ready. Type '退出' to stop.")
    while True:
        user_text = input("\n你：").strip()
        if user_text in {"退出", "exit", "quit"}:
            break
        if not user_text:
            continue

        fixed_reply = safety_reply(user_text)
        if fixed_reply is not None:
            print(f"\n助手：{fixed_reply}")
            history.append({"role": "user", "content": user_text})
            history.append({"role": "assistant", "content": fixed_reply})
            history = trim_history(history)
            continue

        history.append({"role": "user", "content": user_text})
        reply = generate_reply(
            model,
            tokenizer,
            trim_history(history),
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        history.append({"role": "assistant", "content": reply})
        history = trim_history(history)
        print(f"\n助手：{reply}")


if __name__ == "__main__":
    main()

<style>

/* clean ui override */
html, body {
    margin: 0 !important;
    background: #f7f7f8 !important;
    color: #111 !important;
}

body::before,
body::after,
.app::before,
.app::after,
.page::before,
.page::after,
.container::before,
.container::after,
.bg-glow,
.glow,
.light,
.blur,
.ambient,
.radial {
    display: none !important;
}

* {
    box-shadow: none !important;
    text-shadow: none !important;
}

.socrates-bg,
.background-image,
.hero-image,
img {
    filter: none !important;
}

.brand-line {
    position: relative !important;
    z-index: 10 !important;
    display: flex !important;
    justify-content: center !important;
    align-items: baseline !important;
    gap: 18px !important;
    margin-top: 44px !important;
    margin-bottom: 54px !important;
    color: #111 !important;
}

.brand-main {
    font-size: 58px !important;
    font-weight: 700 !important;
    line-height: 1 !important;
    color: #111 !important;
}

.brand-word {
    font-size: 24px !important;
    font-weight: 400 !important;
    line-height: 1 !important;
    letter-spacing: 0.12em !important;
    color: #555 !important;
}

.chat-box,
.message-box,
.assistant-message,
.reply-box,
.response-box,
.bubble,
.card {
    background: #ffffff !important;
    color: #111 !important;
    border: 1px solid #e5e5e5 !important;
    border-radius: 12px !important;
    box-shadow: none !important;
    backdrop-filter: none !important;
}

.input-area,
.input-bar,
.input-panel,
.chat-input-wrapper,
form {
    background: #ffffff !important;
    border: 1px solid #d9d9d9 !important;
    border-radius: 12px !important;
    box-shadow: none !important;
    backdrop-filter: none !important;
}

input,
textarea {
    background: #ffffff !important;
    color: #111 !important;
    border: none !important;
    outline: none !important;
    box-shadow: none !important;
}

input::placeholder,
textarea::placeholder {
    color: #9ca3af !important;
}

button,
.submit-btn,
.confirm-btn {
    background: #111111 !important;
    color: #ffffff !important;
    border: 1px solid #111111 !important;
    border-radius: 10px !important;
    font-weight: 600 !important;
    box-shadow: none !important;
}

button:hover,
.submit-btn:hover,
.confirm-btn:hover {
    background: #000000 !important;
}

@media (max-width: 768px) {
    .brand-line {
        gap: 10px !important;
        margin-top: 32px !important;
        margin-bottom: 36px !important;
        flex-wrap: wrap !important;
    }

    .brand-main {
        font-size: 42px !important;
    }

    .brand-word {
        font-size: 18px !important;
    }
}



/* ===== socratic portrait background + icon override ===== */

html,
body {
    margin: 0 !important;
    background: #f7f7f8 !important;
    color: #111 !important;
    overflow-x: hidden !important;
}

/* 去掉原来的柔光、黄光、阴影 */
body::before,
body::after,
.app::before,
.app::after,
.page::before,
.page::after,
.container::before,
.container::after,
.bg-glow,
.glow,
.light,
.blur,
.ambient,
.radial {
    display: none !important;
}

* {
    box-shadow: none !important;
    text-shadow: none !important;
}

/* 新背景：直接把原来的苏格拉底图片放大 */
.socratic-portrait-bg {
    position: fixed !important;
    inset: 0 !important;
    z-index: 0 !important;
    pointer-events: none !important;
    background-repeat: no-repeat !important;
    background-position: center 24px !important;
    background-size: min(760px, 72vw) auto !important;
    opacity: 0.11 !important;
    filter: grayscale(1) contrast(1.08) !important;
}

/* 页面内容压到背景上面 */
body > *:not(.socratic-portrait-bg) {
    position: relative !important;
    z-index: 1 !important;
}

/* 隐藏原来那张太大的背景图，避免重复 */
.socratic-hidden-source {
    opacity: 0 !important;
    visibility: hidden !important;
}

/* 顶部标题：图标 + Socratic + 三个小词 */
.brand-line {
    position: relative !important;
    z-index: 10 !important;
    display: flex !important;
    justify-content: center !important;
    align-items: baseline !important;
    gap: 16px !important;
    margin-top: 44px !important;
    margin-bottom: 54px !important;
    color: #111 !important;
}

.socratic-mark {
    width: 42px !important;
    height: 42px !important;
    flex: 0 0 auto !important;
    transform: translateY(5px) !important;
}

.brand-main {
    font-size: 58px !important;
    font-weight: 700 !important;
    line-height: 1 !important;
    letter-spacing: 0.01em !important;
    color: #111 !important;
}

.brand-word {
    font-size: 24px !important;
    font-weight: 400 !important;
    line-height: 1 !important;
    letter-spacing: 0.12em !important;
    color: #555 !important;
}

/* GPT 白色对话框 */
.chat-box,
.message-box,
.assistant-message,
.reply-box,
.response-box,
.bubble,
.card {
    background: #ffffff !important;
    color: #111 !important;
    border: 1px solid #e5e5e5 !important;
    border-radius: 12px !important;
    box-shadow: none !important;
    backdrop-filter: none !important;
}

/* 输入框 */
.input-area,
.input-bar,
.input-panel,
.chat-input-wrapper,
form {
    background: #ffffff !important;
    border: 1px solid #d9d9d9 !important;
    border-radius: 12px !important;
    box-shadow: none !important;
    backdrop-filter: none !important;
}

input,
textarea {
    background: #ffffff !important;
    color: #111 !important;
    border: none !important;
    outline: none !important;
    box-shadow: none !important;
}

input::placeholder,
textarea::placeholder {
    color: #9ca3af !important;
}

/* 黑色确认按钮 */
button,
.submit-btn,
.confirm-btn {
    background: #111111 !important;
    color: #ffffff !important;
    border: 1px solid #111111 !important;
    border-radius: 10px !important;
    font-weight: 600 !important;
    box-shadow: none !important;
}

button:hover,
.submit-btn:hover,
.confirm-btn:hover {
    background: #000000 !important;
}

@media (max-width: 768px) {
    .socratic-portrait-bg {
        background-size: 92vw auto !important;
        background-position: center 40px !important;
        opacity: 0.09 !important;
    }

    .brand-line {
        gap: 9px !important;
        margin-top: 32px !important;
        margin-bottom: 36px !important;
        flex-wrap: wrap !important;
    }

    .socratic-mark {
        width: 32px !important;
        height: 32px !important;
        transform: translateY(3px) !important;
    }

    .brand-main {
        font-size: 42px !important;
    }

    .brand-word {
        font-size: 18px !important;
    }
}



/* ===== fix weird inner scrollbar ===== */

html,
body {
    min-height: 100% !important;
    height: auto !important;
    overflow-x: hidden !important;
    overflow-y: auto !important;
}

/* 不让聊天区域自己生成一个夹在中间的滚动条 */
.chat-container,
.chat-wrapper,
.chat-area,
.chat-main,
.chat-history,
.chat-messages,
.messages,
.message-list,
.conversation,
.dialogue,
.dialogue-box,
.main,
.content,
.container,
.app,
.page {
    max-height: none !important;
    height: auto !important;
    overflow-y: visible !important;
    overflow-x: visible !important;
}

/* 页面主体居中，避免内容和滚动条挤在一起 */
.chat-container,
.chat-wrapper,
.chat-area,
.chat-main,
.chat-history,
.chat-messages,
.messages,
.message-list,
.conversation,
.dialogue {
    width: min(100%, 1180px) !important;
    margin-left: auto !important;
    margin-right: auto !important;
}

/* 每条消息别太窄 */
.chat-box,
.message-box,
.assistant-message,
.reply-box,
.response-box,
.bubble,
.card {
    max-width: 880px !important;
}

/* 用户右侧小气泡也别贴着滚动条 */
.user-message,
.user-bubble,
.human-message {
    max-width: 420px !important;
    margin-right: 24px !important;
}

/* 如果某些浏览器仍然显示内部滚动条，直接隐藏内部滚动条 */
.chat-container::-webkit-scrollbar,
.chat-wrapper::-webkit-scrollbar,
.chat-area::-webkit-scrollbar,
.chat-main::-webkit-scrollbar,
.chat-history::-webkit-scrollbar,
.chat-messages::-webkit-scrollbar,
.messages::-webkit-scrollbar,
.message-list::-webkit-scrollbar,
.conversation::-webkit-scrollbar,
.dialogue::-webkit-scrollbar {
    display: none !important;
}

.chat-container,
.chat-wrapper,
.chat-area,
.chat-main,
.chat-history,
.chat-messages,
.messages,
.message-list,
.conversation,
.dialogue {
    scrollbar-width: none !important;
}

/* 输入框固定在底部时，给底部留空间 */
body {
    padding-bottom: 120px !important;
}

@media (max-width: 768px) {
    .chat-box,
    .message-box,
    .assistant-message,
    .reply-box,
    .response-box,
    .bubble,
    .card {
        max-width: calc(100vw - 32px) !important;
    }

    .user-message,
    .user-bubble,
    .human-message {
        max-width: calc(100vw - 72px) !important;
        margin-right: 12px !important;
    }
}

</style>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const nodes = Array.from(document.querySelectorAll("h1, h2, h3, div, header, span"));

    for (const el of nodes) {
        const text = (el.innerText || "").replace(/\s+/g, " ").trim();

        if (
            text.includes("矛盾") &&
            text.includes("思考") &&
            text.includes("前进")
        ) {
            el.innerHTML = `
                <div class="brand-line">
                    <span class="brand-main">Socratic</span>
                    <span class="brand-word">矛盾</span>
                    <span class="brand-word">思考</span>
                    <span class="brand-word">前进</span>
                </div>
            `;
            break;
        }
    }
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const markSvg = `
        <svg class="socratic-mark" viewBox="0 0 64 64" aria-hidden="true">
            <path d="M36 8c-9 1-16 8-18 17-1 6 0 11 4 15" fill="none" stroke="#111" stroke-width="4.2" stroke-linecap="round"/>
            <path d="M38 17c8 2 13 8 13 16 0 8-5 14-12 17" fill="none" stroke="#111" stroke-width="4.2" stroke-linecap="round"/>
            <path d="M26 25c5-3 12-2 16 3" fill="none" stroke="#111" stroke-width="3.6" stroke-linecap="round"/>
            <path d="M25 38c3 4 8 6 13 5" fill="none" stroke="#111" stroke-width="3.6" stroke-linecap="round"/>
            <path d="M32 47c0 5-3 7-7 8" fill="none" stroke="#111" stroke-width="4.2" stroke-linecap="round"/>
            <circle cx="25" cy="59" r="2.8" fill="#111"/>
        </svg>
    `;

    function rewriteTitle() {
        const nodes = Array.from(document.querySelectorAll("h1, h2, h3, div, header, span"));

        for (const el of nodes) {
            const text = (el.innerText || "").replace(/\s+/g, " ").trim();

            if (
                text.includes("矛盾") &&
                text.includes("思考") &&
                text.includes("前进")
            ) {
                el.innerHTML = `
                    <div class="brand-line">
                        ${markSvg}
                        <span class="brand-main">Socratic</span>
                        <span class="brand-word">矛盾</span>
                        <span class="brand-word">思考</span>
                        <span class="brand-word">前进</span>
                    </div>
                `;
                return;
            }
        }
    }

    function pickSocratesImage() {
        const imgs = Array.from(document.images).filter(img => {
            const rect = img.getBoundingClientRect();
            return rect.width > 120 && rect.height > 120;
        });

        if (imgs.length > 0) {
            imgs.sort((a, b) => {
                const ar = a.getBoundingClientRect();
                const br = b.getBoundingClientRect();
                return (br.width * br.height) - (ar.width * ar.height);
            });

            const img = imgs[0];
            img.classList.add("socratic-hidden-source");
            return img.currentSrc || img.src;
        }

        const all = Array.from(document.querySelectorAll("*"));
        for (const el of all) {
            const bg = getComputedStyle(el).backgroundImage;
            if (bg && bg !== "none" && bg.includes("url(")) {
                el.classList.add("socratic-hidden-source");
                return bg.slice(5, -2);
            }
        }

        return null;
    }

    function installBackground() {
        if (document.querySelector(".socratic-portrait-bg")) return;

        const url = pickSocratesImage();
        if (!url) return;

        const bg = document.createElement("div");
        bg.className = "socratic-portrait-bg";
        bg.style.backgroundImage = `url("${url}")`;
        document.body.prepend(bg);
    }

    rewriteTitle();
    installBackground();
});
</script>
