import argparse
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


DEFAULT_PROMPT = Path("/root/socratic-chatbot/prompts/reversal_dialogue_prompt.txt")


CRISIS_KEYWORDS = [
    "想死",
    "去死",
    "自杀",
    "不想活",
    "活不下去",
    "结束生命",
    "伤害自己",
    "杀了自己",
]

CLEAR_INTENT_KEYWORDS = [
    "欺骗",
    "背叛",
    "喜欢",
    "爱",
    "离开",
    "分手",
    "她",
    "他",
    "前任",
    "消息",
    "学习",
    "学",
    "代码",
    "报错",
    "论文",
    "项目",
    "实习",
    "面试",
    "算法",
    "模型",
    "努力",
    "失败",
    "拖延",
    "休息",
    "开始",
    "选择",
    "方向",
    "未来",
    "焦虑",
    "烦",
    "难过",
    "难受",
    "痛苦",
    "孤独",
    "讨厌",
    "害怕",
    "怕",
    "不行",
    "没用",
    "废物",
    "价值",
    "普通",
    "比较",
    "别人",
    "慢",
    "继续",
    "下去",
    "怎么办",
    "怎么",
    "不知道",
    "撑不住",
    "坚持",
]


def looks_unclear(user_text):
    text = user_text.strip()
    compact = "".join(text.split())
    if not compact:
        return True

    # Web terminals often leave broken Chinese fragments with spaces. For short
    # fragmented inputs, asking for clarification is better than hallucinating.
    if any(ch.isspace() for ch in text) and len(compact) <= 16:
        return True

    # Repeated filler characters are usually accidental terminal input.
    unique_chars = set(compact)
    if len(compact) >= 6 and len(unique_chars) <= 3:
        return True

    has_cjk = any("\u4e00" <= ch <= "\u9fff" for ch in compact)
    has_latin = any(("a" <= ch.lower() <= "z") for ch in compact)
    has_clear_intent = any(keyword in compact for keyword in CLEAR_INTENT_KEYWORDS)
    has_punctuation = any(ch in "，。？！、,.?!" for ch in text)
    common_phrase = any(
        phrase in compact
        for phrase in [
            "不知道该怎么",
            "不知道怎么",
            "怎么继续",
            "继续下去",
            "好难受",
            "很难受",
            "太难受",
        ]
    )

    # Mixed random Chinese/Latin fragments like "急哦i解耦" are often broken
    # input. Let clear technical/emotional words pass, otherwise clarify.
    if has_cjk and has_latin and not has_clear_intent:
        return True

    # For short Chinese fragments, require at least one recognizable intent
    # keyword. This prevents the model from inventing meaning from gibberish.
    if (
        has_cjk
        and len(compact) <= 24
        and not has_clear_intent
        and not has_punctuation
        and not common_phrase
    ):
        return True

    # Mostly non-CJK/non-alphanumeric symbols are usually accidental input.
    meaningful = sum(
        "\u4e00" <= ch <= "\u9fff" or ch.isalnum()
        for ch in compact
    )
    if compact and meaningful / len(compact) < 0.6:
        return True

    return False


def safety_reply(user_text):
    compact = user_text.replace(" ", "")
    if any(keyword in compact for keyword in CRISIS_KEYWORDS):
        return (
            "先停一下。这个时候不适合讲哲理。\n\n"
            "请你先离开可能伤害自己的东西，马上联系一个现实中能到你身边的人。"
            "如果你已经有具体计划或工具在身边，请立刻拨打当地紧急电话。"
            "先保证安全，其他事都可以等。"
        )
    return None


def load_system_prompt(path):
    return path.read_text(encoding="utf-8")


def trim_history(history, max_turns=6):
    system = history[:1]
    rest = history[1:]
    return system + rest[-max_turns * 2 :]


def generate_reply(model, tokenizer, messages, max_new_tokens, temperature, top_p):
    prompt = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=1.12,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output_ids[0][inputs["input_ids"].shape[-1] :]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--adapter", default=None)
    parser.add_argument("--system-prompt", type=Path, default=DEFAULT_PROMPT)
    parser.add_argument("--max-new-tokens", type=int, default=180)
    parser.add_argument("--temperature", type=float, default=0.45)
    parser.add_argument("--top-p", type=float, default=0.85)
    args = parser.parse_args()

    system_prompt = load_system_prompt(args.system_prompt)

    tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    )
    if args.adapter:
        model = PeftModel.from_pretrained(model, args.adapter)
    model.eval()

    history = [{"role": "system", "content": system_prompt}]
    print("Reversal dialogue chat is ready. Type '退出' to stop.")

    while True:
        user_text = input("\n你：").strip()
        if user_text in {"退出", "exit", "quit"}:
            break
        if not user_text:
            continue

        fixed = safety_reply(user_text)
        if fixed:
            print(f"\n助手：{fixed}")
            history.append({"role": "user", "content": user_text})
            history.append({"role": "assistant", "content": fixed})
            history = trim_history(history)
            continue

        history.append({"role": "user", "content": user_text})
        reply = generate_reply(
            model,
            tokenizer,
            trim_history(history),
            args.max_new_tokens,
            args.temperature,
            args.top_p,
        )
        history.append({"role": "assistant", "content": reply})
        history = trim_history(history)
        print(f"\n助手：{reply}")


if __name__ == "__main__":
    main()
