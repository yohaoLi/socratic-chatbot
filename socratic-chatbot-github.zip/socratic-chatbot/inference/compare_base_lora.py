import argparse
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


SYSTEM = """你是一个苏格拉底式哲学陪伴助手，但你不是苏格拉底本人。
你温和、清醒、适度提问，擅长帮助用户检查自己的判断。
你不只安慰，也不连续审问。你会抓住用户话里的关键概念，区分事实、感受、解释和审判。
每次最多提出一个关键问题。"""


def load_prompts(path):
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def build_inputs(tokenizer, user_text, device):
    messages = [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": user_text},
    ]
    prompt = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=False,
    )
    return tokenizer(
        prompt,
        return_tensors="pt",
    ).to(device)


def generate(model, tokenizer, prompt, max_new_tokens, temperature, top_p):
    inputs = build_inputs(tokenizer, prompt, model.device)
    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=1.08,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    new_tokens = output_ids[0][inputs["input_ids"].shape[-1] :]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", required=True)
    parser.add_argument("--adapter", required=True)
    parser.add_argument(
        "--prompts",
        type=Path,
        default=Path("/root/socratic-chatbot/eval/test_prompts.txt"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("/root/socratic-chatbot/eval/compare_report.md"),
    )
    parser.add_argument("--max-new-tokens", type=int, default=220)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
    base = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    )
    base.eval()

    prompts = load_prompts(args.prompts)
    rows = ["# Socratic LoRA Comparison\n"]

    print("Generating base model replies...")
    base_replies = []
    for i, prompt in enumerate(prompts, 1):
        print(f"base {i}/{len(prompts)}: {prompt}")
        base_replies.append(
            generate(
                base,
                tokenizer,
                prompt,
                args.max_new_tokens,
                args.temperature,
                args.top_p,
            )
        )

    print("Loading LoRA adapter...")
    lora = PeftModel.from_pretrained(base, args.adapter)
    lora.eval()

    print("Generating LoRA replies...")
    lora_replies = []
    for i, prompt in enumerate(prompts, 1):
        print(f"lora {i}/{len(prompts)}: {prompt}")
        lora_replies.append(
            generate(
                lora,
                tokenizer,
                prompt,
                args.max_new_tokens,
                args.temperature,
                args.top_p,
            )
        )

    for i, (prompt, base_reply, lora_reply) in enumerate(
        zip(prompts, base_replies, lora_replies),
        1,
    ):
        rows.append(f"## {i}. Prompt\n\n{prompt}\n")
        rows.append("### Base\n")
        rows.append(base_reply + "\n")
        rows.append("### LoRA\n")
        rows.append(lora_reply + "\n")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows), encoding="utf-8")
    print(f"Saved report to {args.output}")


if __name__ == "__main__":
    main()

<style>

/* ===== fix weird inner scrollbar ===== */

html,
body {
    min-height: 100% !important;
    height: auto !important;
    overflow-x: hidden !important;
    overflow-y: auto !important;
}

/* 不让聊天区域自己生成一个夹在中间的滚动条 */
.chat-container,
.chat-wrapper,
.chat-area,
.chat-main,
.chat-history,
.chat-messages,
.messages,
.message-list,
.conversation,
.dialogue,
.dialogue-box,
.main,
.content,
.container,
.app,
.page {
    max-height: none !important;
    height: auto !important;
    overflow-y: visible !important;
    overflow-x: visible !important;
}

/* 页面主体居中，避免内容和滚动条挤在一起 */
.chat-container,
.chat-wrapper,
.chat-area,
.chat-main,
.chat-history,
.chat-messages,
.messages,
.message-list,
.conversation,
.dialogue {
    width: min(100%, 1180px) !important;
    margin-left: auto !important;
    margin-right: auto !important;
}

/* 每条消息别太窄 */
.chat-box,
.message-box,
.assistant-message,
.reply-box,
.response-box,
.bubble,
.card {
    max-width: 880px !important;
}

/* 用户右侧小气泡也别贴着滚动条 */
.user-message,
.user-bubble,
.human-message {
    max-width: 420px !important;
    margin-right: 24px !important;
}

/* 如果某些浏览器仍然显示内部滚动条，直接隐藏内部滚动条 */
.chat-container::-webkit-scrollbar,
.chat-wrapper::-webkit-scrollbar,
.chat-area::-webkit-scrollbar,
.chat-main::-webkit-scrollbar,
.chat-history::-webkit-scrollbar,
.chat-messages::-webkit-scrollbar,
.messages::-webkit-scrollbar,
.message-list::-webkit-scrollbar,
.conversation::-webkit-scrollbar,
.dialogue::-webkit-scrollbar {
    display: none !important;
}

.chat-container,
.chat-wrapper,
.chat-area,
.chat-main,
.chat-history,
.chat-messages,
.messages,
.message-list,
.conversation,
.dialogue {
    scrollbar-width: none !important;
}

/* 输入框固定在底部时，给底部留空间 */
body {
    padding-bottom: 120px !important;
}

@media (max-width: 768px) {
    .chat-box,
    .message-box,
    .assistant-message,
    .reply-box,
    .response-box,
    .bubble,
    .card {
        max-width: calc(100vw - 32px) !important;
    }

    .user-message,
    .user-bubble,
    .human-message {
        max-width: calc(100vw - 72px) !important;
        margin-right: 12px !important;
    }
}

</style>
